// Common Locations (can be found on www.weather.com)

// London: UKXX0085 
// San Franciso: USCA0987
// New York: USNY0996
// Madrid: SPXX0050
// Rome: ITXX0067
// Beijing: CHXX0008
// Paris: FRXX0076
// Hong Kong: CHXX0049


var locale = "CHXX0049";